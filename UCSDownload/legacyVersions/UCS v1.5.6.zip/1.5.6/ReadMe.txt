Universal Category System Filename Assistant v1.5 for Universal Category List v6.0 (v1.5.6)
by Michael Pierluissi

This script is possbile thanks to the hard work from the audiophile community.

To use this script:
-Unzip contents to a write access disk.
-The "Settings" menu can be used to edit:
	-Hotkey
	-Short ID List*
	-Source ID List*

*When editing these lists, be sure to put all new entries on a new line. When removing a
selection, remove the entire line.

Example:
	[shortIDList]
	MP
	TN
	KP

Edited to remove MP:
	[shortIDList]
	TN
	KP

**IF UPDATING VERSIONS**
Copy the contents from the sIDList.txt and sourceList.txt in the Data folders from previous
versions, and paste into the corresponding sections of the data.ini file.

***Leave the hotkey value alone or blank. The program fills this area automatically.***

The data.ini will look like this:

[shortIDList]

[sourceList]


Paste all old items *without pipe (|) characters* into new lines to populate the lists.
For example:

[shortIDList]
MP
TN
KP

[sourceList]
MOV
MOV2
MOV3


Disclaimer: The user acknowledges that use of this script will be at their own risk.