Universal Category System Filename Assistant v2.1 for Universal Category List v8.0 (v2.1.8)
by Michael Pierluissi

This script is possbile thanks to the hard work from Tim Nielsen, Kai Paquin, and the
entire audiophile community.

To use this script:
-Unzip file to a write access disk.

-The "Settings" menu can be used to edit:
	-Hotkey
	-UCS filename delivery (Autowrite, Clipboard)
	-Short ID List*
	-Source ID List*

*When editing these lists, be sure to put all new entries on a new line. When removing a
selection, remove the entire line.

Example:
	[creatorIDList]
	MP
	TN
	KP

Edited to remove MP:
	[creatorIDList]
	TN
	KP

Disclaimer: The user acknowledges that use of this script will be at their own risk.