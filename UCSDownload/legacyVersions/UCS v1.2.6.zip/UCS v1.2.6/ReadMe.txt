Universal Category System v1.2 for Universal Category List v6.0 (v1.2.6)
Michael Pierluissi

This script requires current version of AutoHotKey: https://www.autohotkey.com/

DEFAULT HOTKEY: F12

To use this script:
-Unzip contents to a write access disk.
-The "Settings" menu in the first window can be used to edit:
	-Hotkey*
	-Short ID List**
	-Source ID List**
		
*After a hotkey is edited, that command can be used as long as the script remains open. 
 Once the script is manually terminated, it will default to F12.

**When editing these lists, be sure to leave the pipe ( | ) characters
  in tact, unless omitting an entry.
	i.e. Original: MP|TN|RT|
	     Edited to remove MP: TN|RT|


Disclaimer: The user acknowledges that use of this script will be at their own risk.