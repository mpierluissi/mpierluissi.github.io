Universal Category System Filename Assistant v1.4 for Universal Category List v6.0 (v1.4.6)
by Michael Pierluissi

This script is possbile thanks to the hard work from the audiophile community.

To use this script:
-Unzip contents to a write access disk.
-The "Settings" menu in the first window can be used to edit:
	-Hotkey
	-Short ID List*
	-Source ID List*

*When editing these lists, be sure to leave the pipe ( | ) characters in tact,
 unless omitting an entry.

	Example: Original: MP|TN|RT|
	     Edited to remove MP: TN|RT|

**IF UPDATING VERSIONS**
Copy the contents from the sIDList.txt and sourceList.txt in the Data folder from previous
versions, and paste into the same lists located in the new versions' Data folder.


Disclaimer: The user acknowledges that use of this script will be at their own risk.